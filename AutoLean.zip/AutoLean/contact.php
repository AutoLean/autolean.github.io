<?php
//require_once "Mail.php";
$From = "AutoLean Contact <emailrobot@twocapstudios.com>";
$To = "Jeff Jackson <jj@autolean.com>";
$Subject = "Potential Client";
$Host = "twocapstudios.com";
$Username = "emailrobot@twocapstudios.com";
$Password = "HUMm3l01";
$Name = Trim(stripslashes($_REQUEST['Name']));
$Company = Trim(stripslashes($_REQUEST['Company']));
$Phone = Trim(stripslashes($_REQUEST['Phone'])); 
$Email = Trim(stripslashes($_REQUEST['Email'])); 
$Feedback = Trim(stripslashes($_REQUEST['Feedback'])); 

$Body = "";
$Body .= "Name: ";
$Body .= $Name;
$Body .= "\n";
$Body .= "Company: ";
$Body .= $Company;
$Body .= "\n";
$Body .= "Phone: ";
$Body .= $Phone;
$Body .= "\n";
$Body .= "Email: ";
$Body .= $Email;
$Body .= "\n";
$Body .= "Feedback: ";
$Body .= $Feedback;
$Body .= "\n";

//$Headers = array ('From' => $From,'To' => $To,'Subject' => $Subject);
//$SMTP = Mail::factory('smtp',array ('host' => $Host,'auth' => true,'username' => $Username,'password' => $Password));
//$Mail = $SMTP->send($To, $Headers, $Body);
//if (PEAR::isError($Mail)) 
$MailSent = mail($To, $Subject, $Body);
if($MailSent)
{
print "<meta http-equiv=\"refresh\"
| content=\"0;URL=http://www.autolean.com/MessageSent.html#ContactForm\">";
} 
else 
{
print "<meta http-equiv=\"refresh\"
| content=\"0;URL=http://www.autolean.com/MessageError.html#ContactForm\">";
}
?>
